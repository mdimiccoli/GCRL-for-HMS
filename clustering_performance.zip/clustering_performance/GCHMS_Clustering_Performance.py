#!/usr/bin/env python3
# coding: utf-8

import os
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "4"

import sys
import time
import pickle
import numpy as np
from sklearn.metrics.cluster import adjusted_rand_score, normalized_mutual_info_score

import accuracy
from accuracy import *



def truncate(n):
    tc=int(n * 100000) / 100000
    return tc

# import warnings filter
from warnings import simplefilter
# ignore all future warnings
simplefilter(action='ignore', category=FutureWarning)


print('   ')
print('***************************************')
print('********* GC-TSC PERFORMANCE **********')
print('***************************************')

NSEEDS=5



##### WEIZ #######
NSUB=9
GTDIR='./GT/Weiz-GT/'
DATADIR='./Weiz-GCTSC-Labels/'
sub_accZ = np.zeros((NSEEDS,NSUB))
sub_nmiZ = np.zeros((NSEEDS,NSUB))
for i in range(NSUB):
    for k in range(NSEEDS):
        fname   = DATADIR+"seed"+str(k+1)+"/wei_person_"+str(i+1)+"/results.txt"
        ftruth = GTDIR+"wei_person_"+str(i+1)+"_label.npy"
        
        # Load the ground truth
        GT_data = np.load(ftruth)
        GT = GT_data[0,:]
        # Read the estimated labels
        ncuts_labels_Z = np.genfromtxt(fname, dtype=np.int32)
        
        # Compute performance
        _, nmi_Z, _, hr_Z = compacc_sk_h(ncuts_labels_Z,GT)
        sub_accZ[k,i] =hr_Z
        sub_nmiZ[k,i] =nmi_Z

print('* WEIZ DATASET')
print('ACC     / NMI   ')

print(str(truncate(np.mean(sub_accZ))) +' / '+ str(truncate(np.mean(sub_nmiZ))) )
print(str(truncate(np.std(np.mean(sub_accZ,axis=1)))) +' / '+ str(truncate(np.std(np.mean(sub_nmiZ,axis=1)))) )
print('   ')


##### KECK #######
NSUB=4
GTDIR='./GT/Keck-GT/'
DATADIR='./Keck-GCTSC-Labels/'
sub_accZ = np.zeros((NSEEDS,NSUB))
sub_nmiZ = np.zeros((NSEEDS,NSUB))
for i in range(NSUB):
    for k in range(NSEEDS):
        fname   = DATADIR+"seed"+str(k+1)+"/keck_person_"+str(i+1)+"/results.txt"
        ftruth = GTDIR+"keck_person_"+str(i+1)+"_label.npy"
        
        # Load the ground truth
        GT_data = np.load(ftruth)
        GT = GT_data[0,:]
        # Read the estimated labels
        ncuts_labels_Z = np.genfromtxt(fname, dtype=np.int32)
        
        # Compute performance
        _, nmi_Z, _, hr_Z = compacc_sk_h(ncuts_labels_Z,GT)
        sub_accZ[k,i] =hr_Z
        sub_nmiZ[k,i] =nmi_Z

print('* KECK DATASET')
print('ACC     / NMI   ')

print(str(truncate(np.mean(sub_accZ))) +' / '+ str(truncate(np.mean(sub_nmiZ))) )
print(str(truncate(np.std(np.mean(sub_accZ,axis=1)))) +' / '+ str(truncate(np.std(np.mean(sub_nmiZ,axis=1)))) )
print('   ')


##### UT #######
NSUB=10
GTDIR='./GT/UT-GT/'
DATADIR='./UT-GCTSC-Labels/'
sub_accZ = np.zeros((NSEEDS,NSUB))
sub_nmiZ = np.zeros((NSEEDS,NSUB))
for i in range(NSUB):
    for k in range(NSEEDS):
        fname   = DATADIR+"seed"+str(k+1)+"/ut_seq_"+str(i+1)+"/results.txt"
        ftruth = GTDIR+"ut_seq_"+str(i+1)+"_label.npy"
        
        # Load the ground truth
        GT_data = np.load(ftruth)
        GT = GT_data[0,:]
        # Read the estimated labels
        ncuts_labels_Z = np.genfromtxt(fname, dtype=np.int32)
        
        # Compute performance
        _, nmi_Z, _, hr_Z = compacc_sk_h(ncuts_labels_Z,GT)
        sub_accZ[k,i] =hr_Z
        sub_nmiZ[k,i] =nmi_Z

print('* UT DATASET')
print('ACC     / NMI   ')

print(str(truncate(np.mean(sub_accZ))) +' / '+ str(truncate(np.mean(sub_nmiZ))) )
print(str(truncate(np.std(np.mean(sub_accZ,axis=1)))) +' / '+ str(truncate(np.std(np.mean(sub_nmiZ,axis=1)))) )
print('   ')

##### MAD #######
NSUB=40
GTDIR='./GT/MAD-GT/'
DATADIR='./MAD-GCTSC-Labels/'
sub_accZ = np.zeros((NSEEDS,NSUB))
sub_nmiZ = np.zeros((NSEEDS,NSUB))
for l in range(NSEEDS):
    item=0
    for i in range(20):
        for k in range(2):
            fname   = DATADIR+"seed"+str(l+1)+"/sb"+str(i+1)+"seq0"+str(k+1)+"_feature/results.txt"
            ftruth = GTDIR+"sb"+str(i+1)+"seq0"+str(k+1)+"_feature_label.npy"
            
            # Load the ground truth
            GT_data = np.load(ftruth)
            GT = GT_data[0,:]
            # Read the estimated labels
            ncuts_labels_Z = np.genfromtxt(fname, dtype=np.int32)
            
            # Compute performance
            _, nmi_Z, _, hr_Z = compacc_sk_h(ncuts_labels_Z,GT)
            sub_accZ[l,item] =hr_Z
            sub_nmiZ[l,item] =nmi_Z
            item+=1

print('* MAD DATASET')
print('ACC     / NMI   ')

print(str(truncate(np.mean(sub_accZ))) +' / '+ str(truncate(np.mean(sub_nmiZ))) )
print(str(truncate(np.std(np.mean(sub_accZ,axis=1)))) +' / '+ str(truncate(np.std(np.mean(sub_nmiZ,axis=1)))) )
print('   ')
if 0:

    ##### MAD #######
    NSUB=40
    GTDIR='./GT/MAD-GT/'
    DATADIR='./MAD-GCTSC-Labels/'
    sub_accZ = np.zeros(NSUB)
    sub_accZ_bad = np.zeros(NSUB)
    sub_accZ_sk = np.zeros(NSUB)
    sub_nmiZ_sk = np.zeros(NSUB)
    sub_CaccZ = np.zeros(NSUB)
    Goodrate = np.zeros(NSUB)
    item=0
    for i in range(20):
      for k in range(2):
          #print(i,k)
        fname   = DATADIR+"Labels_Z_sb"+str(i+1)+"seq0"+str(k+1)+".txt"
        ftruth = GTDIR+"sb"+str(i+1)+"seq0"+str(k+1)+"_feature_label.npy"
        # Load the ground truth
        GT_data = np.load(ftruth)
        GT = GT_data[0,:]
        # Read the estimated labels
        ncuts_labels_Z = np.genfromtxt(fname, dtype=np.int32)
        # Compute performance
        sub_accZ[item] =compacc(ncuts_labels_Z,GT)
        sub_accZ_sk[item], sub_nmiZ_sk[item] = compacc_sk(ncuts_labels_Z,GT)
        sub_CaccZ[item] =accuracy.classification_accuracy(ncuts_labels_Z,GT)
        Grps,sc = ncuts_labels_Z,GT
        Grps = BestMap(sc, Grps)
        Goodrate[item] = float(np.sum(sc == Grps)) / sc.size
        item+=1

    print('* MAD DATASET')
    print('ACC     / NMI     / ARI     / classACC / Hungarian')
    print(str(truncate(np.mean(sub_accZ))) +' / '+ str(truncate(np.mean(sub_nmiZ_sk))) +' / '+ str(truncate(np.mean(sub_accZ_sk))) +' / '+ str(truncate(np.mean(sub_CaccZ))) +' / '+ str(truncate(np.mean(Goodrate))) )
    print('   ')
    print('***************************************')
    print('   ')
