#!/usr/bin/env python3
# coding: utf-8

import os
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "4"

import sys
import time
import pickle
import numpy as np
from sklearn.metrics.cluster import adjusted_rand_score, normalized_mutual_info_score


##### WEIZ #######
NSUB=9
GTDIR='./GT/Weiz-GT/'
DATADIR='./Weiz-GCTSC-Labels/'
sub_accZ = np.zeros(NSUB)
sub_accZ_sk = np.zeros(NSUB)
sub_nmiZ_sk = np.zeros(NSUB)
for i in range(NSUB):
    fname   = DATADIR+"Labels_Z_person_"+str(i+1)+".txt"
    ftruth = GTDIR+"wei_person_"+str(i+1)+"_label.npy"
    struth = GTDIR+"wei_person_"+str(i+1)+"_label.txt"
    
    # Load the ground truth
    GT_data = np.load(ftruth)
    GT = GT_data[0,:]
    # Write the GT to .txt
    F = open(struth, "w")
    for x in GT:
        F.write(str(x)+" ")
    F.write("\n")
    F.close()




##### KECK #######
NSUB=4
GTDIR='./GT/Keck-GT/'
DATADIR='./Keck-GCTSC-Labels/'
sub_accZ = np.zeros(NSUB)
sub_accZ_bad = np.zeros(NSUB)
sub_accZ_sk = np.zeros(NSUB)
sub_nmiZ_sk = np.zeros(NSUB)
for i in range(NSUB):
    fname   = DATADIR+"Labels_Z_person_"+str(i+1)+".txt"
    ftruth = GTDIR+"keck_person_"+str(i+1)+"_label.npy"
    struth = GTDIR+"keck_person_"+str(i+1)+"_label.txt"
    
    # Load the ground truth
    GT_data = np.load(ftruth)
    GT = GT_data[0,:]
    # Write the GT to .txt
    F = open(struth, "w")
    for x in GT:
        F.write(str(x)+" ")
    F.write("\n")
    F.close()

##### UT #######
NSUB=10
GTDIR='./GT/UT-GT/'
DATADIR='./UT-GCTSC-Labels/'
sub_accZ = np.zeros(NSUB)
sub_accZ_bad = np.zeros(NSUB)
sub_accZ_sk = np.zeros(NSUB)
sub_nmiZ_sk = np.zeros(NSUB)
for i in range(NSUB):
    fname   = DATADIR+"Labels_Z_seq_"+str(i+1)+".txt"
    ftruth = GTDIR+"ut_seq_"+str(i+1)+"_label.npy"
    struth = GTDIR+"ut_seq_"+str(i+1)+"_label.txt"
    
    # Load the ground truth
    GT_data = np.load(ftruth)
    GT = GT_data[0,:]
    # Write the GT to .txt
    F = open(struth, "w")
    for x in GT:
        F.write(str(x)+" ")
    F.write("\n")
    F.close()

##### MAD #######
NSUB=40
GTDIR='./GT/MAD-GT/'
DATADIR='./MAD-GCTSC-Labels/'
sub_accZ = np.zeros(NSUB)
sub_accZ_bad = np.zeros(NSUB)
sub_accZ_sk = np.zeros(NSUB)
sub_nmiZ_sk = np.zeros(NSUB)
item=0
for i in range(20):
  for k in range(2):
    fname   = DATADIR+"Labels_Z_sb"+str(i+1)+"seq0"+str(k+1)+".txt"
    ftruth = GTDIR+"sb"+str(i+1)+"seq0"+str(k+1)+"_feature_label.npy"
    struth = GTDIR+"sb"+str(i+1)+"seq0"+str(k+1)+"_feature_label.txt"
    
    # Load the ground truth
    GT_data = np.load(ftruth)
    GT = GT_data[0,:]
    # Write the GT to .txt
    F = open(struth, "w")
    for x in GT:
      F.write(str(x)+" ")
    F.write("\n")
    F.close()
